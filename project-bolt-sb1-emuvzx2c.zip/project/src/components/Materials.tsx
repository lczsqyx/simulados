import React from 'react';
import { FileText, Download, Book, Video, Link as LinkIcon } from 'lucide-react';

const Materials = () => {
  const materials = {
    documents: [
      {
        title: 'Manual do Arrais Amador',
        description: 'Material oficial da Marinha para habilitação de Arrais',
        size: '2.5 MB',
        type: 'PDF',
      },
      {
        title: 'Regulamento Internacional',
        description: 'RIPEAM - Regulamento Internacional Para Evitar Abalroamento no Mar',
        size: '1.8 MB',
        type: 'PDF',
      },
      {
        title: 'Navegação Costeira',
        description: 'Guia completo de navegação costeira para Mestre Amador',
        size: '3.2 MB',
        type: 'PDF',
      },
    ],
    videos: [
      {
        title: 'Primeiros Socorros a Bordo',
        duration: '15:30',
        views: '1.2k',
      },
      {
        title: 'Técnicas de Navegação',
        duration: '22:45',
        views: '2.5k',
      },
      {
        title: 'Meteorologia Básica',
        duration: '18:20',
        views: '1.8k',
      },
    ],
    links: [
      {
        title: 'Marinha do Brasil',
        url: 'https://www.marinha.mil.br/',
        description: 'Portal oficial da Marinha do Brasil',
      },
      {
        title: 'Capitania dos Portos',
        url: 'https://www.marinha.mil.br/dpc/',
        description: 'Diretoria de Portos e Costas',
      },
    ],
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">
        Materiais de Estudo
      </h1>

      {/* Documentos */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 flex items-center">
          <FileText className="h-6 w-6 mr-3 text-blue-600 dark:text-blue-400" />
          Documentos
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {materials.documents.map((doc, index) => (
            <div
              key={index}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6"
            >
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  {doc.title}
                </h3>
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  {doc.type}
                </span>
              </div>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                {doc.description}
              </p>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  {doc.size}
                </span>
                <button className="flex items-center text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300">
                  <Download className="h-5 w-5 mr-2" />
                  Download
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Vídeos */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 flex items-center">
          <Video className="h-6 w-6 mr-3 text-blue-600 dark:text-blue-400" />
          Vídeo Aulas
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {materials.videos.map((video, index) => (
            <div
              key={index}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden"
            >
              <div className="aspect-w-16 aspect-h-9 bg-gray-200 dark:bg-gray-700">
                {/* Placeholder para thumbnail */}
                <div className="flex items-center justify-center">
                  <Video className="h-12 w-12 text-gray-400" />
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {video.title}
                </h3>
                <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400">
                  <span>{video.duration}</span>
                  <span>{video.views} visualizações</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Links Úteis */}
      <section>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 flex items-center">
          <LinkIcon className="h-6 w-6 mr-3 text-blue-600 dark:text-blue-400" />
          Links Úteis
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {materials.links.map((link, index) => (
            <a
              key={index}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow duration-200"
            >
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                {link.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-300">{link.description}</p>
            </a>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Materials;