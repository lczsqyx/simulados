import React from 'react';
import { Ship, Users, Award, Shield } from 'lucide-react';

const About = () => {
  const features = [
    {
      icon: Ship,
      title: 'Experiência Náutica',
      description: 'Mais de 10 anos preparando navegadores para as certificações da Marinha.',
    },
    {
      icon: Users,
      title: 'Comunidade',
      description: 'Milhares de alunos aprovados formando uma comunidade náutica ativa.',
    },
    {
      icon: Award,
      title: 'Qualidade',
      description: 'Material atualizado e revisado por especialistas do setor náutico.',
    },
    {
      icon: Shield,
      title: 'Confiabilidade',
      description: 'Plataforma segura e confiável para seu aprendizado náutico.',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-6">
          Sobre o Simulados Náuticos
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Somos a principal plataforma de preparação para habilitações náuticas do Brasil,
          ajudando futuros navegadores a conquistarem suas certificações com confiança.
        </p>
      </div>

      {/* Features */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
        {features.map((feature, index) => (
          <div
            key={index}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 text-center"
          >
            <feature.icon className="h-12 w-12 text-blue-600 dark:text-blue-400 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
              {feature.title}
            </h3>
            <p className="text-gray-600 dark:text-gray-300">
              {feature.description}
            </p>
          </div>
        ))}
      </div>

      {/* Mission */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8 mb-16">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
          Nossa Missão
        </h2>
        <p className="text-gray-600 dark:text-gray-300 mb-6">
          Democratizar o acesso ao conhecimento náutico, oferecendo uma plataforma
          moderna e eficiente para preparação das certificações náuticas. Nosso
          compromisso é formar navegadores conscientes e bem preparados para
          garantir a segurança e o prazer da navegação.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
              10k+
            </div>
            <div className="text-gray-600 dark:text-gray-300">
              Alunos Aprovados
            </div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
              5k+
            </div>
            <div className="text-gray-600 dark:text-gray-300">
              Questões no Banco
            </div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
              95%
            </div>
            <div className="text-gray-600 dark:text-gray-300">
              Taxa de Aprovação
            </div>
          </div>
        </div>
      </div>

      {/* Contact */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
          Entre em Contato
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Informações de Contato
            </h3>
            <ul className="space-y-4 text-gray-600 dark:text-gray-300">
              <li>Email: contato@simuladosnauticos.com.br</li>
              <li>Telefone: (11) 99999-9999</li>
              <li>Horário: Segunda a Sexta, 9h às 18h</li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Redes Sociais
            </h3>
            <div className="flex space-x-4">
              <a
                href="#"
                className="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
              >
                Instagram
              </a>
              <a
                href="#"
                className="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
              >
                Facebook
              </a>
              <a
                href="#"
                className="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
              >
                LinkedIn
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;