import React from 'react';
import { X, Anchor, Award, BookOpen, BarChart2, Users, FileText } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (page: 'home' | 'quiz' | 'performance' | 'ranking' | 'materials' | 'about') => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, onNavigate }) => {
  const menuItems = [
    { icon: Anchor, text: 'Início', onClick: () => onNavigate('home') },
    { icon: BookOpen, text: 'Simulados', onClick: () => onNavigate('quiz') },
    { icon: BarChart2, text: 'Desempenho', onClick: () => onNavigate('performance') },
    { icon: Award, text: 'Ranking', onClick: () => onNavigate('ranking') },
    { icon: FileText, text: 'Materiais', onClick: () => onNavigate('materials') },
    { icon: Users, text: 'Sobre', onClick: () => onNavigate('about') },
  ];

  return (
    <div
      className={`fixed inset-y-0 left-0 transform ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      } w-64 bg-white dark:bg-gray-800 overflow-y-auto transition-transform duration-200 ease-in-out z-20`}
    >
      <div className="p-6">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-xl font-bold text-gray-800 dark:text-white">Menu</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-md text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            <X className="h-6 w-6" />
          </button>
        </div>
        <nav>
          <ul className="space-y-2">
            {menuItems.map((item, index) => (
              <li key={index}>
                <button
                  onClick={() => {
                    item.onClick?.();
                    onClose();
                  }}
                  className="flex items-center w-full px-4 py-2 text-gray-700 dark:text-gray-300 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-150"
                >
                  <item.icon className="h-5 w-5 mr-3" />
                  <span>{item.text}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </div>
  );
}

export default Sidebar;