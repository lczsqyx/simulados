import React, { useState, useEffect } from 'react';
import { Timer, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface QuizResults {
  totalQuestions: number;
  correctAnswers: number;
  wrongAnswers: number;
  timeSpent: string;
  answers: { question: number; isCorrect: boolean; selectedAnswer: number }[];
}

const QuizInterface: React.FC = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [progress, setProgress] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<(number | null)[]>(Array(questions.length).fill(null));
  const [showFeedback, setShowFeedback] = useState(false);
  const [timeLeft, setTimeLeft] = useState(45 * 60); // 45 minutes in seconds
  const [isFinished, setIsFinished] = useState(false);
  const [quizResults, setQuizResults] = useState<QuizResults | null>(null);

  // Timer effect
  useEffect(() => {
    if (timeLeft > 0 && !isFinished) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
      return () => clearInterval(timer);
    } else if (timeLeft === 0 && !isFinished) {
      finishQuiz();
    }
  }, [timeLeft, isFinished]);

  // Format time remaining
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const questions = [
    {
      text: "Qual é a idade mínima para obter a habilitação de Arrais Amador?",
      options: ["18 anos", "21 anos", "16 anos", "20 anos"],
      correctAnswer: 0,
      explanation: "A idade mínima para obter a habilitação de Arrais Amador é 18 anos, conforme regulamentação da Marinha do Brasil."
    },
    {
      text: "O que significa a sigla RIPEAM?",
      options: [
        "Registro Internacional de Pequenas Embarcações Marítimas",
        "Regulamento Internacional Para Evitar Abalroamento no Mar",
        "Registro de Inspeção de Pequenas Embarcações da Amazônia",
        "Regulamento de Inspeção de Portos e Embarcações da Marinha"
      ],
      correctAnswer: 1,
      explanation: "RIPEAM significa Regulamento Internacional Para Evitar Abalroamento no Mar, um conjunto de regras fundamentais para a navegação segura."
    },
    {
      text: "Qual é o significado de uma boia cardinal Norte?",
      options: [
        "Indica águas seguras para navegação",
        "Indica que há perigo isolado",
        "Indica que há águas navegáveis ao Norte da boia",
        "Indica uma área especial"
      ],
      correctAnswer: 2,
      explanation: "A boia cardinal Norte indica que as águas navegáveis estão ao Norte da boia. É identificada pela cor preta sobre amarelo e dois cones pretos apontando para cima."
    },
    {
      text: "O que é um través?",
      options: [
        "A parte da frente da embarcação",
        "A linha perpendicular ao eixo longitudinal da embarcação",
        "A parte traseira da embarcação",
        "O fundo da embarcação"
      ],
      correctAnswer: 1,
      explanation: "Través é a linha imaginária perpendicular ao eixo longitudinal (comprimento) da embarcação, formando um ângulo de 90 graus com a proa."
    },
    {
      text: "Qual é a função do extintor de incêndio classe B?",
      options: [
        "Combater incêndios em materiais sólidos",
        "Combater incêndios em líquidos inflamáveis",
        "Combater incêndios em equipamentos elétricos",
        "Combater incêndios em metais"
      ],
      correctAnswer: 1,
      explanation: "O extintor classe B é específico para combater incêndios em líquidos inflamáveis, como gasolina, óleo, tintas e graxas."
    },
    {
      text: "O que significa quando uma embarcação está no bordo BB?",
      options: [
        "Está navegando para frente",
        "Está navegando para trás",
        "Está navegando para bombordo (lado esquerdo)",
        "Está navegando para boreste (lado direito)"
      ],
      correctAnswer: 2,
      explanation: "Quando uma embarcação está no bordo BB, significa que está navegando para bombordo, que é o lado esquerdo da embarcação quando se olha da popa para a proa."
    }
  ];

  const handleAnswerSelect = (index: number) => {
    if (selectedAnswers[currentQuestion] !== null) return; // Prevent changing answer
    const newSelectedAnswers = [...selectedAnswers];
    newSelectedAnswers[currentQuestion] = index;
    setSelectedAnswers(newSelectedAnswers);
    setShowFeedback(true);
    setProgress(((currentQuestion + 1) / questions.length) * 100);
  };

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setShowFeedback(false);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
      setShowFeedback(true); // Show feedback for previous answer
    }
  };

  const finishQuiz = () => {
    const results: QuizResults = {
      totalQuestions: questions.length,
      correctAnswers: 0,
      wrongAnswers: 0,
      timeSpent: formatTime((45 * 60) - timeLeft),
      answers: []
    };

    selectedAnswers.forEach((answer, index) => {
      if (answer !== null) {
        const isCorrect = answer === questions[index].correctAnswer;
        results.answers.push({
          question: index,
          isCorrect,
          selectedAnswer: answer
        });
        if (isCorrect) {
          results.correctAnswers++;
        } else {
          results.wrongAnswers++;
        }
      }
    });

    setQuizResults(results);
    setIsFinished(true);
  };

  if (isFinished && quizResults) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl mx-auto"
      >
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
            Resultado do Simulado
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="bg-blue-50 dark:bg-blue-900/20 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-blue-900 dark:text-blue-100 mb-2">
                Resumo
              </h3>
              <div className="space-y-2">
                <p className="text-blue-800 dark:text-blue-200">
                  Acertos: {quizResults.correctAnswers} de {quizResults.totalQuestions}
                </p>
                <p className="text-blue-800 dark:text-blue-200">
                  Taxa de Acerto: {((quizResults.correctAnswers / quizResults.totalQuestions) * 100).toFixed(1)}%
                </p>
                <p className="text-blue-800 dark:text-blue-200">
                  Tempo Total: {quizResults.timeSpent}
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {questions.map((question, index) => (
              <div
                key={index}
                className="bg-gray-50 dark:bg-gray-700/50 p-6 rounded-lg"
              >
                <h4 className="font-medium text-gray-900 dark:text-white mb-4">
                  {index + 1}. {question.text}
                </h4>
                <div className="space-y-2">
                  {question.options.map((option, optionIndex) => (
                    <div
                      key={optionIndex}
                      className={`p-3 rounded-lg ${
                        selectedAnswers[index] === optionIndex
                          ? optionIndex === question.correctAnswer
                            ? 'bg-green-100 dark:bg-green-900/40'
                            : 'bg-red-100 dark:bg-red-900/40'
                          : optionIndex === question.correctAnswer
                          ? 'bg-green-100 dark:bg-green-900/40'
                          : 'bg-gray-100 dark:bg-gray-800/40'
                      }`}
                    >
                      <span className="text-gray-800 dark:text-gray-200">
                        {option}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto"
    >
      {/* Barra de progresso */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
            Questão {currentQuestion + 1} de {questions.length}
          </span>
          <div className="flex items-center text-sm font-medium text-gray-700 dark:text-gray-300">
            <Timer className="h-4 w-4 mr-2" />
            <span>Tempo restante: {formatTime(timeLeft)}</span>
          </div>
        </div>
        <div className="h-2 bg-gray-200 rounded-full dark:bg-gray-700">
          <motion.div
            className="h-2 bg-blue-600 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>
      </div>

      {/* Questão */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentQuestion}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-8"
        >
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
            {questions[currentQuestion].text}
          </h2>

          <div className="space-y-4">
            {questions[currentQuestion].options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswerSelect(index)}
                disabled={selectedAnswers[currentQuestion] !== null}
                className={`w-full text-left p-4 rounded-lg transition-all duration-200 ${
                  selectedAnswers[currentQuestion] === index
                    ? index === questions[currentQuestion].correctAnswer
                      ? 'bg-green-100 dark:bg-green-900 border-green-500'
                      : 'bg-red-100 dark:bg-red-900 border-red-500'
                    : 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600'
                } ${
                  showFeedback && index === questions[currentQuestion].correctAnswer
                    ? 'border-2 border-green-500'
                    : 'border-2 border-transparent'
                }`}
              >
                <div className="flex items-center">
                  <span className="flex-grow text-gray-800 dark:text-gray-200">
                    {option}
                  </span>
                  {showFeedback && selectedAnswers[currentQuestion] === index && (
                    index === questions[currentQuestion].correctAnswer ? (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-500" />
                    )
                  )}
                </div>
              </button>
            ))}
          </div>

          {/* Feedback */}
          {showFeedback && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/50 rounded-lg"
            >
              <div className="flex items-start">
                <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5 mr-2" />
                <p className="text-sm text-blue-800 dark:text-blue-200">
                  {questions[currentQuestion].explanation}
                </p>
              </div>
            </motion.div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Navegação */}
      <div className="flex justify-between">
        <button
          onClick={handlePreviousQuestion}
          disabled={currentQuestion === 0}
          className={`px-4 py-2 rounded-lg ${
            currentQuestion === 0
              ? 'text-gray-400 dark:text-gray-600 cursor-not-allowed'
              : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700'
          }`}
        >
          Questão Anterior
        </button>
        {currentQuestion === questions.length - 1 ? (
          <button
            onClick={finishQuiz}
            className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-6 rounded-lg transition duration-150 ease-in-out"
          >
            Finalizar Simulado
          </button>
        ) : (
          <button
            onClick={handleNextQuestion}
            className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-lg transition duration-150 ease-in-out"
          >
            Próxima Questão
          </button>
        )}
      </div>
    </motion.div>
  );
};

export default QuizInterface;

export default QuizInterface