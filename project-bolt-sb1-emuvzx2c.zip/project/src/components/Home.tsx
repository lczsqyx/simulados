import React from 'react';
import { Anchor, Users, Database, Trophy } from 'lucide-react';

interface HomeProps {
  onStartQuiz: () => void;
}

const Home: React.FC<HomeProps> = ({ onStartQuiz }) => {
  const stats = [
    { icon: Users, label: 'Usuários', value: '10,000+' },
    { icon: Database, label: 'Questões', value: '5,000+' },
    { icon: Trophy, label: 'Taxa de Aprovação', value: '95%' },
  ];

  const categories = [
    { title: 'Arrais Amador', description: 'Habilitação para conduzir embarcações de recreio' },
    { title: 'Motonauta', description: 'Habilitação específica para pilotar motos aquáticas' },
    { title: 'Mestre Amador', description: 'Navegação costeira e comando de embarcações' },
    { title: 'Capitão Amador', description: 'Navegação oceânica e comando de embarcações' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
          Prepare-se para seu exame náutico!
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
          A melhor plataforma para estudar e praticar simulados náuticos
        </p>
        <button
          onClick={onStartQuiz}
          className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg transition duration-150 ease-in-out transform hover:scale-105"
        >
          Começar Simulado
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        {stats.map((stat, index) => (
          <div
            key={index}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 text-center"
          >
            <stat.icon className="h-8 w-8 text-blue-600 dark:text-blue-400 mx-auto mb-4" />
            <div className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
              {stat.value}
            </div>
            <div className="text-gray-600 dark:text-gray-300">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Categories */}
      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8 text-center">
        Categorias de Simulados
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {categories.map((category, index) => (
          <div
            key={index}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow duration-200"
          >
            <div className="flex items-center mb-4">
              <Anchor className="h-6 w-6 text-blue-600 dark:text-blue-400 mr-3" />
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                {category.title}
              </h3>
            </div>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              {category.description}
            </p>
            <button
              onClick={onStartQuiz}
              className="w-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-800 dark:text-white font-medium py-2 px-4 rounded-lg transition duration-150 ease-in-out"
            >
              Iniciar Simulado
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Home;