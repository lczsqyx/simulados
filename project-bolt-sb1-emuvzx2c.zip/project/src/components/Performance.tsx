import React from 'react';
import { BarChart2, TrendingUp, Clock, Target, Brain } from 'lucide-react';

const Performance = () => {
  const performanceData = {
    totalQuestions: 150,
    correctAnswers: 127,
    averageTime: '45s',
    weakestTopics: ['Navegação Noturna', 'Regras de Tráfego', 'Primeiros Socorros'],
    strongestTopics: ['Equipamentos Obrigatórios', 'Legislação Básica'],
  };

  const categories = [
    { name: 'Arrais Amador', progress: 85 },
    { name: 'Motonauta', progress: 70 },
    { name: 'Mestre Amador', progress: 45 },
    { name: 'Capitão Amador', progress: 30 },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">
        Seu Desempenho
      </h1>

      {/* Estatísticas Gerais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          <div className="flex items-center mb-4">
            <Target className="h-6 w-6 text-blue-600 dark:text-blue-400 mr-3" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              Taxa de Acerto
            </h3>
          </div>
          <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">
            {Math.round((performanceData.correctAnswers / performanceData.totalQuestions) * 100)}%
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          <div className="flex items-center mb-4">
            <Brain className="h-6 w-6 text-blue-600 dark:text-blue-400 mr-3" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              Questões Respondidas
            </h3>
          </div>
          <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">
            {performanceData.totalQuestions}
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          <div className="flex items-center mb-4">
            <Clock className="h-6 w-6 text-blue-600 dark:text-blue-400 mr-3" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              Tempo Médio
            </h3>
          </div>
          <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">
            {performanceData.averageTime}
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          <div className="flex items-center mb-4">
            <TrendingUp className="h-6 w-6 text-blue-600 dark:text-blue-400 mr-3" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              Evolução Semanal
            </h3>
          </div>
          <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">
            +15%
          </p>
        </div>
      </div>

      {/* Progresso por Categoria */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-12">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
          Progresso por Categoria
        </h2>
        <div className="space-y-6">
          {categories.map((category) => (
            <div key={category.name}>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {category.name}
                </span>
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {category.progress}%
                </span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full dark:bg-gray-700">
                <div
                  className="h-2 bg-blue-600 rounded-full transition-all duration-300"
                  style={{ width: `${category.progress}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Pontos Fortes e Fracos */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
            Pontos Fortes
          </h2>
          <ul className="space-y-4">
            {performanceData.strongestTopics.map((topic, index) => (
              <li
                key={index}
                className="flex items-center text-green-600 dark:text-green-400"
              >
                <Target className="h-5 w-5 mr-3" />
                <span>{topic}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
            Pontos a Melhorar
          </h2>
          <ul className="space-y-4">
            {performanceData.weakestTopics.map((topic, index) => (
              <li
                key={index}
                className="flex items-center text-red-600 dark:text-red-400"
              >
                <Target className="h-5 w-5 mr-3" />
                <span>{topic}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Performance;