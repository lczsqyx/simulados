import React from 'react';
import { Trophy, Medal, Star, Crown } from 'lucide-react';

const Ranking = () => {
  const topUsers = [
    { name: 'Marina Silva', score: 980, questions: 450, accuracy: 98 },
    { name: 'João Santos', score: 945, questions: 420, accuracy: 95 },
    { name: 'Pedro Costa', score: 920, questions: 400, accuracy: 92 },
    { name: 'Ana Oliveira', score: 890, questions: 380, accuracy: 89 },
    { name: 'Carlos Lima', score: 860, questions: 350, accuracy: 86 },
  ];

  const getIcon = (position: number) => {
    switch (position) {
      case 0:
        return <Crown className="h-8 w-8 text-yellow-400" />;
      case 1:
        return <Medal className="h-8 w-8 text-gray-400" />;
      case 2:
        return <Medal className="h-8 w-8 text-amber-600" />;
      default:
        return <Star className="h-8 w-8 text-blue-400" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex items-center mb-8">
        <Trophy className="h-8 w-8 text-yellow-400 mr-4" />
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
          Ranking dos Navegadores
        </h1>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
        <div className="grid grid-cols-5 gap-4 p-6 bg-gray-50 dark:bg-gray-700 border-b border-gray-200 dark:border-gray-600">
          <div className="col-span-2 font-semibold text-gray-900 dark:text-white">
            Navegador
          </div>
          <div className="text-center font-semibold text-gray-900 dark:text-white">
            Pontuação
          </div>
          <div className="text-center font-semibold text-gray-900 dark:text-white">
            Questões
          </div>
          <div className="text-center font-semibold text-gray-900 dark:text-white">
            Precisão
          </div>
        </div>

        {topUsers.map((user, index) => (
          <div
            key={index}
            className={`grid grid-cols-5 gap-4 p-6 items-center ${
              index % 2 === 0 ? 'bg-white dark:bg-gray-800' : 'bg-gray-50 dark:bg-gray-700'
            }`}
          >
            <div className="col-span-2 flex items-center space-x-4">
              {getIcon(index)}
              <div>
                <p className="font-semibold text-gray-900 dark:text-white">
                  {user.name}
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {index === 0 ? 'Capitão do Ranking' : `${index + 1}º Lugar`}
                </p>
              </div>
            </div>
            <div className="text-center font-bold text-blue-600 dark:text-blue-400">
              {user.score}
            </div>
            <div className="text-center text-gray-700 dark:text-gray-300">
              {user.questions}
            </div>
            <div className="text-center text-green-600 dark:text-green-400">
              {user.accuracy}%
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
          Como funciona o ranking?
        </h2>
        <ul className="space-y-4 text-gray-700 dark:text-gray-300">
          <li className="flex items-center">
            <Star className="h-5 w-5 text-blue-600 dark:text-blue-400 mr-3" />
            Pontos por resposta correta: 10
          </li>
          <li className="flex items-center">
            <Star className="h-5 w-5 text-blue-600 dark:text-blue-400 mr-3" />
            Bônus por velocidade: até 5 pontos extras
          </li>
          <li className="flex items-center">
            <Star className="h-5 w-5 text-blue-600 dark:text-blue-400 mr-3" />
            Bônus por sequência de acertos: até 20 pontos
          </li>
          <li className="flex items-center">
            <Star className="h-5 w-5 text-blue-600 dark:text-blue-400 mr-3" />
            Ranking atualizado semanalmente
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Ranking;