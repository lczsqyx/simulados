import React, { useState, useEffect } from 'react';
import { Moon, Sun, Ship, Menu } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import QuizInterface from './components/QuizInterface';
import Sidebar from './components/Sidebar';
import Home from './components/Home';
import Performance from './components/Performance';
import Ranking from './components/Ranking';
import Materials from './components/Materials';
import About from './components/About';

function App() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState<'home' | 'quiz' | 'performance' | 'ranking' | 'materials' | 'about'>('home');

  useEffect(() => {
    // Check system preference for dark mode
    if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setIsDarkMode(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  const pageVariants = {
    initial: { opacity: 0, x: 20 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: -20 }
  };

  const renderCurrentPage = () => {
    return (
      <AnimatePresence mode="wait">
        <motion.div
          key={currentPage}
          initial="initial"
          animate="animate"
          exit="exit"
          variants={pageVariants}
          transition={{ duration: 0.2 }}
        >
          {(() => {
            switch (currentPage) {
              case 'quiz':
                return <QuizInterface />;
              case 'performance':
                return <Performance />;
              case 'ranking':
                return <Ranking />;
              case 'materials':
                return <Materials />;
              case 'about':
                return <About />;
              default:
                return <Home onStartQuiz={() => setCurrentPage('quiz')} />;
            }
          })()}
        </motion.div>
      </AnimatePresence>
    );
  };

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark' : ''}`}>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
        {/* Header */}
        <header className="bg-white dark:bg-gray-800 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center">
                <button
                  onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                  className="p-2 rounded-md text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <Menu className="h-6 w-6" />
                </button>
                <div 
                  className="flex items-center ml-4 cursor-pointer"
                  onClick={() => setCurrentPage('home')}
                >
                  <Ship className="h-8 w-8 text-blue-600 dark:text-blue-400" />
                  <h1 className="ml-2 text-xl font-bold text-gray-900 dark:text-white">
                    Simulados Náuticos
                  </h1>
                </div>
              </div>
              <button
                onClick={toggleDarkMode}
                className="p-2 rounded-md text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                aria-label={isDarkMode ? 'Ativar modo claro' : 'Ativar modo escuro'}
              >
                {isDarkMode ? (
                  <Sun className="h-6 w-6" />
                ) : (
                  <Moon className="h-6 w-6" />
                )}
              </button>
            </div>
          </div>
        </header>

        <div className="flex">
          <Sidebar 
            isOpen={isSidebarOpen} 
            onClose={() => setIsSidebarOpen(false)}
            onNavigate={(page) => {
              if (page === 'quiz') {
                setCurrentPage('home');
              } else {
                setCurrentPage(page);
              }
            }}
          />
          <main className="flex-1 p-4">
            {renderCurrentPage()}
          </main>
        </div>
      </div>
    </div>
  );
}

export default App;